The board outline is defined by a 10mil trace found on all gerbers.

